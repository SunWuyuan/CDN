<?php

/**
 * Project LOGGED v1.8 API Credentials File
 * by PlanetCloud (https://www.byet.net/index.php?/profile/528767-planetcloud/)
 * ---
 * Read the documentation for more information.
 */

return [
    'YOUR_ID_HERE' => [
        'domain' => 'DOMAIN_HERE',
        'key' => 'YOUR_KEY_HERE',
    ]
];