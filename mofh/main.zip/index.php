<?php

/**
 * Project LOGGED v1.8 Privacy Policy
 * ---
 * No modifications is necessary in this file.
 */


# Initialize
define('THIS_DIR', dirname(__FILE__));
require THIS_DIR . '/sys-auth/app/app.php';
?>

<!DOCTYPE html>
<html lang="zh-CN">

<head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Webpixels">
    <title><?= config('company.name'); ?></title>
    <style>
        @keyframes hidePreloader {
            0% {
                width: 100%;
                height: 100%;
            }

            100% {
                width: 0;
                height: 0;
            }
        }

        body>div.preloader {
            position: fixed;
            background: white;
            width: 100%;
            height: 100%;
            z-index: 1071;
            opacity: 0;
            transition: opacity .5s ease;
            overflow: hidden;
            pointer-events: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        body:not(.loaded)>div.preloader {
            opacity: 1;
        }

        body:not(.loaded) {
            overflow: hidden;
        }

        body.loaded>div.preloader {
            animation: hidePreloader .5s linear .5s forwards;
        }
    </style>
    <script>
        window.addEventListener("load", function () {
            setTimeout(function () {
                document.querySelector('body').classList.add('loaded');
            }, 300);
        });
    </script>
    <!-- Favicon -->
    <link rel="icon" href="http://192325.xyz/logo.ico" type="image/png">
    <!-- Quick CSS -->
    <link rel="stylesheet" href="assets/css/quick-website.css" id="stylesheet">
</head>


<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">加载中...</span>
        </div>
    </div>


    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <!-- Brand -->
            <a class="navbar-brand" href="#">
                <img alt="Image placeholder"
                    src="<?= config('company.logo'); ?>"
                    id="navbar-logo">
            </a>
            <!-- Toggler -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="navbarCollapse">

                <ul class="navbar-nav mt-4 mt-lg-0 ml-auto">


                          
                    <li class="nav-item dropdown dropdown-animate" data-toggle="hover">
                        <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">关于</a>

                        <div class="card dropdown-menu dropdown-menu-single">
                           <!-- <div class="card shadow-none">
                                <div class="p-3 d-flex">

                                    <div>
                                        <span class="h6" style="white-space:nowrap">孙悟元</span>
                                        <p class="text-sm text-muted mb-0" style="white-space:nowrap">
                                            B站up主
                                        </p><a href="https://wuyuan.dev" class="btn btn-sm btn-primary"
                                            style="white-space:nowrap">访问我的博客</a>

                                    </div>
                                </div>
                            </div>
    -->
                            <p class="text-sm text-muted mb-0" style="white-space:nowrap">
                                使用
                                <a href="https://ifastnet.com/portal/aff.php?aff=29619" class="" style="white-space:nowrap">iFastNet</a> 的基础设施
                            </p>


                        </div>
            </div>
            </li>

            </ul>
            <!-- Button -->
            <a class="navbar-btn btn btn-sm btn-primary d-none d-lg-inline-block ml-3"
                href="http://<?= $_SERVER['HTTP_HOST']?>/auth/signup">
                免费注册
            </a>

        </div>
    </nav>
    <!-- Main content -->
    <section class="slice py-7">
        <div class="container">
            <div class="row row-grid align-items-center">
                <div class="col-12 col-md-5 col-lg-6 order-md-2 text-center">
                    <!-- Image -->
                    <figure class="w-100">
                        <img alt="Image placeholder" src="img.svg" class="img-fluid mw-md-120">
                    </figure>
                </div>
                <div class="col-12 col-md-7 col-lg-6 order-md-1 pr-md-5">
                    <!-- Heading -->
                    <h1 class="display-4 text-center text-md-left mb-3">
                        获取您的 <br /><strong class="text-primary">免费虚拟主机</strong>
                    </h1>
                    <!-- Text -->
                    <p class="lead text-center text-md-left text-muted">
                        使用我们的免费虚拟主机服务，快捷高效！
                    </p>
                    <!-- Buttons -->
                    <div class="text-center text-md-left mt-5">
                        <a href="http://<?= $_SERVER['HTTP_HOST'] ?>/auth/signup" class="btn btn-primary btn-icon" target="_blank">
                            <span class="btn-inner--text">立即开始</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-chevron-right">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </a>
                        <a href="<?= config('company.abouturl'); ?>" class="btn btn-neutral btn-icon d-none d-lg-inline-block"
                            target="_blank">了解更多</a>
                    </div>
                </div>
            </div>
        </div>
    </section>




    <!-- Core JS  -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
   <!-- Quick JS -->
    <script src="assets/js/quick-website.js"></script>
    <!-- Feather Icons -->
   
</body>

</html>