<?php

/**
 * Project LOGGED v1.8 Configuration File
 * by PlanetCloud (https://www.byet.net/index.php?/profile/528767-planetcloud/)
 * ---
 * Read the documentation for more information.
 */

$config = [

    # System Settings
    'sys' => [

        # Site Settings
        'debug_mode' => false,
        'color_scheme' => 'pink',
        'cpanel_url' => '192325.xyz',

        # Form Settings
        'enable_login_form' => true,
        'enable_signup_form' => true,
        'enable_domain_selector' => false,
        'domain_selection' => [
            '192325.xyz',
        ],
        'accept_request_from_other_logged' => true,

        # Additional Features
        'feature' => [
            'remember_username' => true,
            'language_selector' => true,
        ]
    ],

    # Company Settings
    'company' => [
        'name' => '悟元云托管',
        'logo' => 'http://192325.xyz/mofh.png',
        'logo_type' => 'image',
        'slogan' => '知识创造一切',
        'main_domain' => 'https://wuyuan.dev',
        'favicon' => 'http://192325.xyz/logo.ico',
        'contact_email' => 'sun@wuyuan.dev',
        'report_abuse_email' => 'sun@wuyuan.dev',
        'abouturl' => 'https://wuyuan.dev'
    ],

    # Page settings
    'page' => [

        # Page Titles
        'titles' => [
            'login' => '登录',
            'signup' => '注册',
            'terms' => '服务条款',
            'privacy' => '隐私政策',
            'creating_account' => '创建您的帐户请稍候...',
            'error' => '出了点问题'
        ],

        # Page Messages
        'messages' => [
            'login' => '登录',
            'signup' => '注册',
            'terms' => '服务条款',
            'privacy' => '隐私政策',
            'creating_account' => '创建您的帐户...',
            'creating_account_error' => '出现错误，请稍后再试'
        ]
    ]
];

/**
 * --- DANGER ZONE ---
 * Stop editting below this line.
 */

# Check if file was accessed directly.
if (!defined('APP') or explode('/', $_SERVER['REQUEST_URI'])[1] === 'sys-auth') {
    die(header("HTTP/1.1 403 Forbidden"));
}

# Additional modifications
$config['sys']['captcha_id'] = md5(rand(6000, PHP_INT_MAX));
$config['sys']['current_domain'] = strtolower(preg_replace('/^www\./', '', $_SERVER['HTTP_HOST']));

if (!empty($config['sys']['cpanel_url'])) {
    $config['sys']['cpanel_url'] = "cpanel.{$config['sys']['cpanel_url']}";
} else {
    $config['sys']['cpanel_url'] = "cpanel.{$config['sys']['current_domain']}";
}

$config['sys']['form_target'] = [
    'login' => "https://{$config['sys']['cpanel_url']}/login.php",
    'signup' => "https://ifastnet.com/register2.php"
];
