<?php

/**
 * Project LOGGED v1.8 Target Credentials File
 * by PlanetCloud (https://www.byet.net/index.php?/profile/528767-planetcloud/)
 * ---
 * Read the documentation for more information.
 */

return [
    'hosting1.com' => [
        'identifier' => 'YOUR_ID_HERE',
        'key' => 'YOUR_KEY_HERE',
        'protocol' => 'https'
    ],
    'hosting2.com' => [
        'identifier' => 'YOUR_ID_HERE',
        'key' => 'YOUR_KEY_HERE',
        'protocol' => 'https'
    ]
];